package com.mygdx.game.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class HowToState extends State {

    private Texture background;
    private Texture message;
    private Texture back;

    public HowToState(GameStateManager gsm) {
        super(gsm);
        background = new Texture("black.png");
        message = new Texture("wasd.png");
        back = new Texture("back.png");
    }

    @Override
    public void handleInput() {
        if(Gdx.input.isKeyJustPressed(Input.Keys.BACKSPACE)){
            gsm.set(new MenuState(gsm));
            dispose();
        }
    }

    @Override
    public void update(float dt) {
        handleInput();

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(background, 0, 0, 720, 480);
        sb.draw(message, 720/2 - 100, 480/2, 200, 200);
        sb.draw(back, 10,425 , 50, 50);
        sb.end();

    }

    @Override
    public void dispose() {
        background.dispose();
        message.dispose();
        back.dispose();
    }
}
