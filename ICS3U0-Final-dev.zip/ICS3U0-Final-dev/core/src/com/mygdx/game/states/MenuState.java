package com.mygdx.game.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import static jdk.nashorn.internal.objects.Global.println;

public class MenuState extends State {
    private Texture background;
    private Texture playButton;
    private Texture howToPlay;

    public MenuState(GameStateManager gsm) {
        super(gsm);
        background = new Texture("black.png");
        playButton = new Texture("play.png");
        howToPlay = new Texture("howtoplay.png");

    }

    @Override
    public void handleInput() {
        if(Gdx.input.isKeyJustPressed(Input.Keys.ENTER)){
            gsm.set(new PlayState(gsm));
            dispose();
        }
        if(Gdx.input.isKeyJustPressed(Input.Keys.Q)){
            gsm.set(new HowToState(gsm));
            dispose();
        }

    }

    @Override
    public void update(float dt) {
        handleInput();

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(background, 0, 0, 720, 480);
        sb.draw(playButton, 720/2 - 50, 480/2, 100, 100);
        sb.draw(howToPlay, 720/2 - 75, 480/2 - 100, 150, 50);
        sb.end();
    }

    @Override
    public void dispose() {
        background.dispose();
        playButton.dispose();

    }
}
