<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="industrial.v1" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="industrial.v1.png" width="512" height="512"/>
</tileset>
